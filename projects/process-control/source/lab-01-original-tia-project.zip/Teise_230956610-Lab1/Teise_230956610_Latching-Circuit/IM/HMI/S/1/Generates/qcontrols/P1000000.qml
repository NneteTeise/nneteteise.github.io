﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777216
	objId: 16777216
	x: 0
	y: 0
	width: 800
	height: 480
	IGuiButton
	{
		id: q486539293
		objId: 486539293
		x: 140
		y: 85
		width: 96
		height: 32
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ff00ff00"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiQmlCircle
	{
		id: q671088650
		objId: 671088650
		x: 596
		y: 71
		width: 62
		height: 62
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_Radius : 31
		qm_EllipseWidth: 62
		qm_EllipseHeight: 62
	}
	IGuiTextField
	{
		id: q268435467
		objId: 268435467
		x: 323
		y: 1
		width: 203
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicView
	{
		id: q301989888
		objId: 301989888
		x: 339
		y: 128
		width: 188
		height: 100
		qm_Transparent : true 
		qm_ImageWidth: 188
		qm_ImageHeight: 100
		qm_SourceSizeWidth: 188
		qm_SourceSizeHeight: 100
	}
	IGuiButton
	{
		id: q486539294
		objId: 486539294
		x: 139
		y: 169
		width: 96
		height: 32
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffff0000"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiQmlRectangle
	{
		id: q671088651
		objId: 671088651
		x: 406
		y: 191
		width: 44
		height: 28
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 44
		qm_RectangleHeight: 28
	}
	IGuiTextField
	{
		id: q268435468
		objId: 268435468
		x: 663
		y: 81
		width: 123
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiQmlCircle
	{
		id: q671088652
		objId: 671088652
		x: 596
		y: 157
		width: 62
		height: 62
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_Radius : 31
		qm_EllipseWidth: 62
		qm_EllipseHeight: 62
	}
	IGuiTextField
	{
		id: q268435469
		objId: 268435469
		x: 663
		y: 175
		width: 134
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
}
