﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777216
	objId: 16777216
	x: 0
	y: 0
	width: 800
	height: 480
	IGuiTextField
	{
		id: q268435465
		objId: 268435465
		x: 28
		y: 55
		width: 640
		height: 25
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicView
	{
		id: q301989889
		objId: 301989889
		x: 47
		y: 223
		width: 188
		height: 100
		qm_Transparent : true 
		qm_ImageWidth: 188
		qm_ImageHeight: 100
		qm_SourceSizeWidth: 188
		qm_SourceSizeHeight: 100
	}
	IGuiGraphicView
	{
		id: q301989890
		objId: 301989890
		x: 252
		y: 62
		width: 49
		height: 58
		qm_Transparent : true 
		qm_ImageWidth: 49
		qm_ImageHeight: 58
		qm_SourceSizeWidth: 49
		qm_SourceSizeHeight: 58
	}
	IGuiGraphicView
	{
		id: q301989891
		objId: 301989891
		x: 17
		y: 208
		width: 378
		height: 33
		qm_Transparent : true 
		qm_ImageWidth: 378
		qm_ImageHeight: 33
		qm_SourceSizeWidth: 378
		qm_SourceSizeHeight: 33
	}
	IGuiButton
	{
		id: q486539304
		objId: 486539304
		x: 358
		y: 362
		width: 96
		height: 32
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ff00cfff"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiButton
	{
		id: q486539305
		objId: 486539305
		x: 506
		y: 360
		width: 111
		height: 32
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffffff00"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiButton
	{
		id: q486539306
		objId: 486539306
		x: 654
		y: 358
		width: 125
		height: 32
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffce9aff"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiIOField
	{
		id: q33554441
		objId: 33554441
		x: 312
		y: 82
		width: 67
		height: 32
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 4
		qm_ImageSource: "image://QSmartImageProvider/50#2#4#128#0#0"
		qm_Border.top: 5
		qm_Border.bottom: 5
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 6
		qm_Anchors.leftMargin: 7
		qm_Anchors.rightMargin: 6
		qm_Anchors.topMargin: 6
	}
	IGuiButton
	{
		id: q486539307
		objId: 486539307
		x: 112
		y: 282
		width: 43
		height: 31
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiButton
	{
		id: q486539308
		objId: 486539308
		x: 100
		y: 364
		width: 96
		height: 32
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ff00ff00"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiButton
	{
		id: q486539309
		objId: 486539309
		x: 222
		y: 362
		width: 96
		height: 32
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffff0000"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiGraphicView
	{
		id: q301989892
		objId: 301989892
		x: 350
		y: 256
		width: 189
		height: 34
		qm_Transparent : true 
		qm_ImageWidth: 189
		qm_ImageHeight: 34
		qm_SourceSizeWidth: 189
		qm_SourceSizeHeight: 34
	}
	IGuiGraphicView
	{
		id: q301989893
		objId: 301989893
		x: 72
		y: 144
		width: 37
		height: 84
		qm_Transparent : true 
		qm_ImageWidth: 37
		qm_ImageHeight: 84
		qm_SourceSizeWidth: 37
		qm_SourceSizeHeight: 84
	}
}
